/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package planets;

import java.io.IOException;
import java.util.ArrayList;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import org.xml.sax.SAXException;

/**
 *
 * @author Nagababu Rellacharla
 */
public class PlanetsListParserDriver {

    /**
     * @param args the command line arguments
     * @throws org.xml.sax.SAXException
     * @throws javax.xml.parsers.ParserConfigurationException
     * @throws java.io.IOException
     * @throws javax.xml.xpath.XPathExpressionException
     */
    public static void main(String[] args)
            throws SAXException, ParserConfigurationException, IOException, XPathExpressionException {
        PlanetsListParser parser = new PlanetsListParser();
        ArrayList<Planets> planetsList = parser.getPlanetsFromXMLFile("planets.xml");

        int diaIndex = 0;
        int massIndex = 0;

        for (int i = 1; i < planetsList.size(); i++) {

            if (planetsList.get(diaIndex).getDiameter() < planetsList.get(i).getDiameter()) {
                diaIndex = i;
            }
            if (planetsList.get(massIndex).getMass() > planetsList.get(i).getMass()) {
                massIndex = i;
            }

        }
        System.out.println("The name of the planet with the largest diameter is: " + planetsList.get(diaIndex).getName());
        System.out.println("The name of the planet with the smallets mass is:   " + planetsList.get(massIndex).getName());
        double sum = 0.0;
        for (Planets p : planetsList) {
            sum += p.getPeriodOfRevolution();
        }

        System.out.printf("The average period of revolution for the planets is: %.3f \n", +sum / planetsList.size());
    }

}
