package planets;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Nagababu Rellacharla
 */
public class Planets {

    private String name;
    private double averageDistanceFromSun;
    private double periodOfRevolution;
    private double diameter;
    private double mass;
    private double gravity;

    public Planets() {
    }

    public Planets(String name, double averageDistanceFromSun, double periodOfRevolution, double diameter, double mass, double gravity) {
        this.name = name;
        this.averageDistanceFromSun = averageDistanceFromSun;
        this.periodOfRevolution = periodOfRevolution;
        this.diameter = diameter;
        this.mass = mass;
        this.gravity = gravity;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAverageDistanceFromSun(double averageDistanceFromSun) {
        this.averageDistanceFromSun = averageDistanceFromSun;
    }

    public void setPeriodOfRevolution(double periodOfRevolution) {
        this.periodOfRevolution = periodOfRevolution;
    }

    public void setDiameter(double diameter) {
        this.diameter = diameter;
    }

    public void setMass(double mass) {
        this.mass = mass;
    }

    public void setGravity(double gravity) {
        this.gravity = gravity;
    }

    public String getName() {
        return name;
    }

    public double getAverageDistanceFromSun() {
        return averageDistanceFromSun;
    }

    public double getPeriodOfRevolution() {
        return periodOfRevolution;
    }

    public double getDiameter() {
        return diameter;
    }

    public double getMass() {
        return mass;
    }

    public double getGravity() {
        return gravity;
    }

    @Override
    public String toString() {
        return "Planets{" + "name=" + name + ", averageDistanceFromSun=" + averageDistanceFromSun + ", periodOfRevolution=" + periodOfRevolution + ", diameter=" + diameter + ", mass=" + mass + ", gravity=" + gravity + '}';
    }

}
