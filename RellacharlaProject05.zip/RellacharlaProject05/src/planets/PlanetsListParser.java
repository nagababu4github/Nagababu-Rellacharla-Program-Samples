/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package planets;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

/**
 *
 * @author Nagababu Rellacharla
 */
public class PlanetsListParser {

    private DocumentBuilder builder;
    private XPath path;

    public PlanetsListParser() throws ParserConfigurationException {
        builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        path = XPathFactory.newInstance().newXPath();
    }

    public ArrayList<Planets> getPlanetsFromXMLFile(String fileName)
            throws SAXException, IOException, XPathExpressionException {
        // Parse file and build DOM tree.
        Document doc = builder.parse(new File(fileName));

        // Count the dog elements.
        int planetCount = Integer.parseInt(path.evaluate("count(/solarSystem/planet)", doc));

        // Extract dog information from the XML document and represent the
        // information as an ArrayList of Dog objects.
        ArrayList<Planets> planetList = new ArrayList<>();
        for (int i = 1; i <= planetCount; ++i) {
            String name = path.evaluate("/solarSystem/planet[" + i + "]/name", doc);
            double averageDistanceFromSun = Double.parseDouble(path.evaluate("/solarSystem/planet[" + i + "]/averageDistanceFromSun", doc));
            double periodOfRevolution = Double.parseDouble(path.evaluate("/solarSystem/planet[" + i + "]/periodOfRevolution", doc));
            double diameter = Double.parseDouble(path.evaluate("/solarSystem/planet[" + i + "]/diameter", doc));
            double mass = Double.parseDouble(path.evaluate("/solarSystem/planet[" + i + "]/mass", doc));
            double gravity = Double.parseDouble(path.evaluate("/solarSystem/planet[" + i + "]/gravity", doc));
            planetList.add(new Planets(name, averageDistanceFromSun, periodOfRevolution, diameter, mass, gravity));
        }
        return planetList;
    }

}
