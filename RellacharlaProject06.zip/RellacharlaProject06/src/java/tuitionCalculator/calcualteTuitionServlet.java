/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tuitionCalculator;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Nagababu Rellacharla
 */
@WebServlet(name = "calcualteTuitionServlet", urlPatterns = {"/calcualteTuitionServlet"})
public class calcualteTuitionServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet calcualteTuitionServlet</title>");
            out.println("</head>");
            out.println("<body>");
            String residency = request.getParameter("inresidency");
            String under = request.getParameter("under");
            int cr = Integer.parseInt(request.getParameter("creditHours"));
            double tuition = 0.0;
            System.out.printf("%.2f", tuition);
            System.out.println("Hiiiiiii " + residency);
            if (residency.equals("instate")) {
                if (under.equals("under")) {
                    tuition = 271.85 * cr;
                } else {
                    tuition = 345.72 * cr;
                }
            } else if (residency.equals("outstate")) {
                if (under.equals("under")) {
                    tuition = 480.24 * cr;
                } else {
                    tuition = 593.49 * cr;
                }
            }
            System.out.println(tuition);

            out.print("<h1>Your tuition is $");
            out.printf("%.2f", tuition);
            out.println("</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
