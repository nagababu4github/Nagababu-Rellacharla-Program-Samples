package manufacturer;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.model.SelectItem;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

/**
 *
 * @author Nagababu Rellacharla
 */
@ManagedBean
@Named(value = "manufacturerBean")
@RequestScoped
public class manufacturerBean {

    private String stateCode;
    SelectItem[] stateCodes;

    public String getStateCode() {
        return stateCode;
    }

    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }

    @PersistenceUnit(unitName = "RellacharlaProject12PU")
    private EntityManagerFactory emf = null;

    /**
     * Creates a new instance of manufacturerBean
     */
    public manufacturerBean() {
    }

    public SelectItem[] getStateCodes() {
        EntityManager em = emf.createEntityManager();
        List<String> sl = (em.createQuery(
                "select DISTINCT m.state from Manufacturer m").getResultList());
        stateCodes = new SelectItem[sl.size()];
        for (int i = 0; i < sl.size(); i++) {
            stateCodes[i] = new SelectItem(sl.get(i));
        }
        return stateCodes;

    }

    public List<Manufacturer> getAllManufacturers() {
        EntityManager em = emf.createEntityManager();
        Query querybystatecode = em.createNamedQuery("Manufacturer.findByState");
        querybystatecode.setParameter("state", stateCode);
        return querybystatecode.getResultList();
    }

}
