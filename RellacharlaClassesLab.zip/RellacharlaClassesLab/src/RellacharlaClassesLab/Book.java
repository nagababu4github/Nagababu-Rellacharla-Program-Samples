/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RellacharlaClassesLab;

/**
 * Book class contains details of the book
 *
 * @author Nagababu Rellacharla
 */
public class Book {

    private String title;
    private int year;
    private double retailPrice;
    private double saleDiscount;

    /**
     * This is the constructor created with the given signature
     *
     * @param title this parameter represents the title of the book
     * @param year this parameter represents the year of publishing in double
     * @param retailPrice Retails price of the book
     * @param saleDiscount Discount on Book
     */
    public Book(String title, int year, double retailPrice, double saleDiscount) {
        this.title = title;
        this.year = year;
        this.retailPrice = retailPrice;
        this.saleDiscount = saleDiscount;
    }

    /**
     * This method is used to return the title of the book
     *
     * @return The Title of the book
     */
    public String getTitle() {

        return title;
    }

    /**
     * This method is for returning the Year of publish
     *
     * @return Return the year of the book published
     */
    public int getYear() {

        return year;
    }

    /**
     * This method is used for returning the Sale discount on book
     *
     * @return This method returns the Sale Discount on the Book
     */
    public double getSaleDiscount() {

        return saleDiscount;
    }

    /**
     * This method is to return the Retail Price of the book
     *
     * @return This method is written to return the Retail Price of the book
     */
    public double getRetailPrice() {

        return retailPrice;
    }

    /**
     * This method is used to return the sale price that is calculated
     *
     * @return Sale Price of the book will be returned
     */
    public double getSalePrice() {
        double salePrice;
        salePrice = retailPrice - retailPrice * saleDiscount;
        return salePrice;
    }

}
