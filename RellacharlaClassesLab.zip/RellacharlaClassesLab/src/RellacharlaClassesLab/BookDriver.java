/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RellacharlaClassesLab;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 * Book driver class is used to create book object and find the selling price of
 * the book
 *
 * @author Nagababu Rellacharla
 */
public class BookDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner bookDetails = new Scanner(System.in);

        System.out.println("Enter the title of the book:");
        String title = bookDetails.nextLine();
        System.out.println("Enter the year the book was published:");
        int year = bookDetails.nextInt();
        System.out.println("Enter the retail price of the book:");
        double retailPrice = bookDetails.nextDouble();
        System.out.println("Enter the sales discount of the book:");
        double saleDiscount = bookDetails.nextDouble();
        System.out.println("Enter the number of books:");
        int numberOfBooks = bookDetails.nextInt();

        Book printBook = new Book(title, year, retailPrice, saleDiscount);

        System.out.println("\n" + numberOfBooks + " " + printBook.getTitle());

        DecimalFormat sp = new DecimalFormat("####.##");

        System.out.println("Retail Price:" + sp.format(numberOfBooks * printBook.getRetailPrice()));

        double sellingPrice = numberOfBooks * printBook.getSalePrice();
        System.out.println("Sale Price:" + sp.format(sellingPrice));

    }

}
