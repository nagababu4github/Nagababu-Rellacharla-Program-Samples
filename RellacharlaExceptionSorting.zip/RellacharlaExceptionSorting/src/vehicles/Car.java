/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicles;

/**
 *
 * @author Nagababu Rellacharla
 */
public class Car extends Vehicle {

    private int capacity;

    public Car(int capacity, String color, int year, int wheels) {
        super(color, year, wheels);
        this.capacity = capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public int getCapacity() {
        return capacity;
    }

    @Override
    public String toString() {
        return super.toString() + ", capacity:" + capacity;
    }

}
