/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicles;

/**
 *
 * @author Nagababu Rellacharla
 */
public class Bike extends Vehicle {

    private int size;

    public Bike(int capacity, String color, int year, int wheels) {
        super(color, year, wheels);
        this.size = capacity;
    }

    public void setSize(int capacity) {
        this.size = capacity;
    }

    public int getSize() {
        return size;
    }

    @Override
    public String toString() {
        return super.toString() + ", Size:" + size;
    }

}
