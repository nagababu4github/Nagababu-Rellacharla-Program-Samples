/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicles;

import java.io.File;
import java.io.FileNotFoundException;

import java.util.Scanner;

/**
 *
 * @author Nagababu Rellacharla
 */
public class VehiclesDriver {

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here
        // Step 1 - Begin
        /**
         * Step 1. Test the class Car.
         */
        Car car1 = new Car(15, "Green", 2000, 4);
        System.out.println(car1);
        Car car2 = new Car(6, "Red", 2010, 6);
        car2.setCapacity(8);
        car2.setColor("Black");
        car2.setWheels(4);
        car2.setYear(2011);
        System.out.println("The capacity of the 2nd car: " + car2.getCapacity());
        System.out.println("The color of the 2nd car: " + car2.getColor());
        System.out.println("The year of the 2nd car: " + car2.getYear());
        System.out.println("The number of wheels of the 2nd car: " + car2.getWheels());
        System.out.println("Information for car2: " + car2);
        // Step 1 - End
//       
        // Step 2 - Begin
        /**
         * Step 2. Test the class Bike.
         */
        Bike bk1 = new Bike(43, "Green", 2000, 2);
        System.out.println(bk1);
        Bike bk2 = new Bike(58, "Red", 2010, 2);
        bk2.setSize(36);
        bk2.setColor("Black");
        bk2.setYear(2011);
        System.out.println("The size of the 2nd bike: " + bk2.getSize());
        System.out.println("The color of the 2nd bike: " + bk2.getColor());
        System.out.println("The year of the 2nd bike: " + bk2.getYear());
        System.out.println("The number of wheels of the 2nd bike: " + bk2.getWheels());
        System.out.println("Information for bike: " + bk2);
        // Step 2 - End
        //Step 3: Parts(1-3) - Begin
        System.out.println("");
        VehicleList vlist = new VehicleList();
        try {
            vlist.addVehicle(car1);
        } catch (IllegalArgumentException e) {
            System.out.println("The capacity of this car is too large! " + car1.toString());
        }
        try {
            vlist.addVehicle(bk2);
        } catch (IllegalArgumentException e) {
            System.out.println("The size of this bike is too small! " + bk2.toString());
        }
        //Step 3: Parts(1-3) - End
        //Step 3: Part(4) - Begin
        vlist.addVehicle(car2);
        vlist.addVehicle(bk1);
        vlist.countNumberOfVehiclesPerType();
        //Step 3: Part(4) - End

        //Step 4: - Begin
        System.out.println("");
        //Add your code here.
        Scanner vehicles = new Scanner(new File("VehiclesData.txt"));
        while (vehicles.hasNext()) {
            String type = vehicles.next();
            Vehicle v = null;
            if (type.equals("Bike")) {
                int size = vehicles.nextInt();
                String color = vehicles.next();
                int year = vehicles.nextInt();
                int wheels = vehicles.nextInt();
                v = new Bike(size, color, year, wheels);
            } else {
                int capacity = vehicles.nextInt();
                String color = vehicles.next();
                int year = vehicles.nextInt();
                int wheels = vehicles.nextInt();
                v = new Car(capacity, color, year, wheels);
            }
            try {
                vlist.addVehicle(v);
            } catch (IllegalArgumentException e) {
                System.out.println("IllegalArgumentException occurred!" + v + "\n" + e);
            }

        }
        System.out.println(vlist);
        vlist.sortVehicles();
        System.out.println("\nSort the vehicles by the natural order of vehicles." + vlist);

        vlist.sortVehiclesByWheels();
        System.out.println("\nSort the vehicles by the wheels and colors of vehicles." + vlist);

        //Step 4: - End
//        
        System.out.println("");
        //Step 5: - Begin
        System.out.println("Run an enhanced for loop to iterate elements through vlist in the driver class:");
        for (Vehicle vi : vlist) {
            System.out.println(vi);
        }
        //Step 5: - End
    }

}
