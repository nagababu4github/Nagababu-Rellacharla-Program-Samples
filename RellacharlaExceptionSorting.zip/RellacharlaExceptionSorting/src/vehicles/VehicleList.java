/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicles;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

/**
 *
 * @author Nagababu Rellacharla
 */
public class VehicleList implements Iterable<Vehicle> {

    private ArrayList<Vehicle> vehiclelist;

    public VehicleList() {
        vehiclelist = new ArrayList<>();
    }

    public void addVehicle(Vehicle v) {

        if (v instanceof Car) {
            if (((Car) v).getCapacity() > 10) {
                throw new IllegalArgumentException();
            }
        } else {
            if ((((Bike) v).getSize()) < 40) {
                throw new IllegalArgumentException();
            }
        }
        vehiclelist.add(v);
    }

    public void countNumberOfVehiclesPerType() {
        int carCount = 0;
        int bikeCount = 0;
        for (int i = 0; i < vehiclelist.size(); i++) {

            if ((vehiclelist.get(i)) instanceof Car) {
                carCount++;
            } else if ((vehiclelist.get(i)) instanceof Bike) {
                bikeCount++;

            }

        }
        System.out.println("The number of cars is " + carCount);
        System.out.println("The number of bikes is " + bikeCount);
    }

    public void sortVehicles() {
        Collections.sort(vehiclelist);
    }

    public void sortVehiclesByWheels() {
        Collections.sort(vehiclelist, new Comparator<Vehicle>() {
            @Override
            public int compare(Vehicle v1, Vehicle v2) {
                if (v1.getWheels() == v2.getWheels()) {
                    return v1.getColor().compareTo(v2.getColor());
                } else {
                    return v1.getWheels() - v2.getWheels();
                }
            }
        });
    }

    @Override
    public String toString() {
        String s = String.format("");
        for (Vehicle v : vehiclelist) {
            s += "\n" + v;
        }
        return s;
    }

    @Override
    public Iterator<Vehicle> iterator() {
        return vehiclelist.iterator();
    }

}
