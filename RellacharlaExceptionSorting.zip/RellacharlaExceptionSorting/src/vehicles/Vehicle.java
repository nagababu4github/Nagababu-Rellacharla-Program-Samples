/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicles;

/**
 *
 * @author Nagababu Rellacharla
 */
public class Vehicle implements Comparable<Vehicle> {

    private String color;
    private int year;
    private int wheels;

    public Vehicle(String color, int year, int wheels) {
        this.color = color;
        this.year = year;
        this.wheels = wheels;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getWheels() {
        return wheels;
    }

    public void setWheels(int wheels) {
        this.wheels = wheels;
    }

    @Override
    public String toString() {
        return "Vehicle: color:" + color + ", year:" + year + ", wheels:" + wheels;
    }

    @Override
    public int compareTo(Vehicle o) {
        return this.getYear() - o.getYear();
    }

}
