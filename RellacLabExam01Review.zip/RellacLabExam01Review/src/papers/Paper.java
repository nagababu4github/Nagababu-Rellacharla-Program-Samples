/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package papers;

/**
 *
 * @author Nagababu Rellacharla
 */
public class Paper {

    private String title;
    private int reviewscorea;
    private int reviewscoreb;
    private int year;
    private String track;
    private String decision;
    public static final int THRESHOLD = 3;

    /**
     * This is no argument constructor used to set initial values for all the
     * paper details
     */
    public Paper() {
        this.title = "unknown";
        this.decision = "unknown";
        this.reviewscorea = 0;
        this.reviewscoreb = 0;
        this.year = 0;
        this.track = "unknwon";
    }

    /**
     * This constructor is used to create paper object and print the output
     *
     * @param title paper title
     * @param reviewscorea reviewer A score for a paper
     * @param reviewscoreb reviewer B score for a paper
     * @param year the year when the paper was published
     * @param track the track where the paper was published
     */
    public Paper(String title, int reviewscorea, int reviewscoreb, int year, String track) {
        this.title = title;
        this.reviewscorea = reviewscorea;
        this.reviewscoreb = reviewscoreb;
        this.year = year;
        this.track = track;
        this.decision = "unknown";
    }

    /**
     * This method is to set the final decision for the paper
     */
    public void finalDecision() {
        double avg = (getReviewscorea() + getReviewscoreb()) / 2;
        if (avg < THRESHOLD) {
            decision = "reject";
        } else {
            decision = "accept";
        }
    }

    /**
     *
     * @return Decision of the paper
     */
    public String getDecision() {

        return decision;
    }

    /**
     *
     * @return The title of the paper
     */
    public String getTitle() {
        return title;
    }

    /**
     *
     * @return Returns the Reviewer A score for the paper
     */
    public int getReviewscorea() {
        return reviewscorea;
    }

    /**
     *
     * @return Returns the Reviewer B score for the paper
     */
    public int getReviewscoreb() {
        return reviewscoreb;
    }

    /**
     *
     * @return the year in which the paper published
     */
    public int getYear() {
        return year;
    }

    /**
     *
     * @return returns the track of the paper
     */
    public String getTrack() {
        return track;
    }

    /**
     *
     * @return evaluates and returns the maximum reviewer score from A and B
     */
    public int max() {
        int a = getReviewscorea();
        int b = getReviewscoreb();
        if (a < b) {
            return b;
        } else {
            return a;
        }
    }

    /**
     *
     * @return evaluates and returns the minimum reviewer score from A and B
     */
    public int min() {
        int a = getReviewscorea();
        int b = getReviewscoreb();
        if (a < b) {
            return a;
        } else {
            return b;
        }
    }

    /**
     *
     * @param title sets the title for the paper
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     *
     * @param reviewscorea Sets the reviewer A score
     */
    public void setReviewscorea(int reviewscorea) {
        this.reviewscorea = reviewscorea;
    }

    /**
     *
     * @param reviewscoreb Sets the reviewer B score
     */
    public void setReviewscoreb(int reviewscoreb) {
        this.reviewscoreb = reviewscoreb;
    }

    /**
     *
     * @param year sets the year of paper published
     */
    public void setYear(int year) {
        this.year = year;
    }

    /**
     *
     * @param track sets the track of the paper
     */
    public void setTrack(String track) {
        this.track = track;
    }

    /**
     *
     * @param decision Sets decision of the paper to accept or reject
     */
    public void setDecision(String decision) {
        this.decision = decision;
    }

    /**
     *
     * @return the output string to print
     */
    @Override
    public String toString() {
        String fromattedString = String.format("%-40s:%6d:%30s\n", title, year, track);
        fromattedString += String.format("%d %d [%s]", reviewscorea, reviewscoreb, decision);

        return fromattedString;
    }

}
