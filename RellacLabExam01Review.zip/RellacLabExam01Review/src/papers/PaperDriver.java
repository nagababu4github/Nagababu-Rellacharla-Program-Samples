/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package papers;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author Nagababu Rellacharla
 */
public class PaperDriver {

    public static void main(String[] args) throws FileNotFoundException {

        //Step: Create an object of Paper class with no-arg constructor
        Paper mypaper1 = new Paper();
        System.out.println(mypaper1);
        //Step: Test setters
        int scorea = 4, scoreb = 3;
        mypaper1.setTitle("Friendship Privacy");
        mypaper1.setTrack("security");
        mypaper1.setYear(2011);
        mypaper1.setReviewscorea(scorea);
        mypaper1.setReviewscoreb(scoreb);
        mypaper1.setDecision("accept");
        System.out.println(mypaper1);
        //Step: Creat another object of Paper class with the parameterized constructor
        int score2a = 2, score2b = 3;
        Paper mypaper2 = new Paper("Botnet Detection", score2a, score2b, 2013, "security");
        //Step: Test getters
        System.out.println("The tile of my 2nd paper: " + mypaper2.getTitle());
        System.out.println("It's published in the year of " + mypaper2.getYear() + " at the track of " + mypaper2.getTrack());
        System.out.println("The review scores are " + mypaper2.getReviewscorea() + " and " + mypaper2.getReviewscoreb());
        System.out.println("The higher score is " + mypaper2.max());
        System.out.println("The lower score is " + mypaper2.min());
        mypaper2.finalDecision();
        System.out.println("The decision on accepting that paper is [" + mypaper2.getDecision() + "].");
        System.out.println("");
////        /*  Block I - start */
////        //Step: Write a while loop to read papers from the file. In each iteration 
////        //of the loop, you need to read data, create an object of Paper using the 
////        //data and call finalDecison() through the object. Then if the paper is 
////        //accepted by the track of "security" in 2014, you print out the title of the paper.
////        //Add your code here.
        Scanner mypaper = new Scanner(new File("data.txt"));
        while (mypaper.hasNext()) {
            String title = mypaper.nextLine();
            int rscorea = mypaper.nextInt();
            int rscoreb = mypaper.nextInt();
            int year = mypaper.nextInt();
            mypaper.nextLine();
            String track = mypaper.nextLine();
            Paper mypaper0 = new Paper(title, rscorea, rscoreb, year, track);
            if (("security".equals(mypaper0.getTrack())) && (mypaper0.getYear() == 2014)) {
                mypaper0.finalDecision();
                if ("accept".equals(mypaper0.getDecision())) {
                    System.out.println(mypaper0.getTitle());
                }
            }

//        /*  Block I - end */
        }
        mypaper.close();
    }

}
