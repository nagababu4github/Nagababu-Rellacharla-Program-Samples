/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package horses;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author Nagababu Rellacharla
 */
public class HorseList implements Iterable<Horse> {

    private ArrayList<Horse> horses;

    public HorseList() {
        horses = new ArrayList<Horse>();
    }

    public void addHorse(Horse h) {
        horses.add(h);

    }

    @Override
    public Iterator<Horse> iterator() {
        return horses.iterator();

    }

}
