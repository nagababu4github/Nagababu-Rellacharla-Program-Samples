/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package horses;

import java.util.ArrayList;

/**
 *
 * @author Nagababu Rellacharla
 */
public class ShowHorse extends Horse {

    private ArrayList<EventInfo> showRecord;

    public ShowHorse(String horseName, int yearOfBirth) {
        super(horseName, yearOfBirth);
        showRecord = new ArrayList<>();
    }

    public void addEventToShowRecord(EventInfo e) {
        showRecord.add(e);
    }

    @Override
    public String toString() {
        String res = super.toString() + " ";
        if (showRecord.isEmpty()) {
            res += "\n" + "No show record";
        } else {
            for (EventInfo e : showRecord) {
                res += "\n" + e;
            }

        }

        return res;
    }

}
