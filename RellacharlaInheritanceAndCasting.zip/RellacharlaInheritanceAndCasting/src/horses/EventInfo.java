/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package horses;

/**
 *
 * @author Nagababu Rellacharla
 */
public class EventInfo {

    private String eventName;
    private int points;

    public EventInfo(String eventName, int points) {
        this.eventName = eventName;
        this.points = points;
    }

    @Override
    public String toString() {
        return String.format("%-20s %6d", eventName, points);

    }

}
