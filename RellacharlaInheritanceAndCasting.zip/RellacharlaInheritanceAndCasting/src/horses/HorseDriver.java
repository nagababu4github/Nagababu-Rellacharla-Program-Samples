/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package horses;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author Nagababu Rellacharla
 */
public class HorseDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        HorseList myHorses = new HorseList();

        Scanner h = new Scanner(new File("horses.txt"));
        Horse myHorse;

        while (h.hasNext()) {
            String name = h.nextLine();
            int year = h.nextInt();
            boolean isShowHorse = Boolean.parseBoolean(h.next());
            h.nextLine();
            if (isShowHorse) {
                myHorse = new ShowHorse(name, year);

                String s = h.nextLine();
                while ((!"*".equals(s))) {
                    String[] eventAndPoint = s.split(" ");
                    String event = eventAndPoint[0];
                    int points = Integer.parseInt(eventAndPoint[1]);
                    s = h.nextLine();
                    EventInfo e = new EventInfo(event, points);
                    ((ShowHorse) myHorse).addEventToShowRecord(e);

                }

            } else {
                myHorse = new Horse(name, year);
                h.nextLine();

            }

            myHorses.addHorse(myHorse);

        }

        for (Horse t : myHorses) {
            System.out.println(t + "\n");
        }

    }

}
