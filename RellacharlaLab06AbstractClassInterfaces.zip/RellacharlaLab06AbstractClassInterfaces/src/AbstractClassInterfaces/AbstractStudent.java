package AbstractClassInterfaces;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Nagababu Rellacharla
 */
public abstract class AbstractStudent {

    private String nameStudent;
    private double annualTuition;

    public AbstractStudent(String nameStudent, double annualTuition) {
        this.nameStudent = nameStudent;
        this.annualTuition = annualTuition;
    }

    public double getAnnualTuition() {

        return annualTuition;
    }

    public abstract double getTuition();

    @Override
    public String toString() {
        String returnValue = String.format("%-20s %10.2f ", nameStudent, annualTuition);
        return returnValue;
    }

}
