package AbstractClassInterfaces;

public class Driver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        
        // AbstractStudent abstractStudent = new AbstractStudent("Alex", 2300.0);
        //AbstarctStudent is a abstract class and can not instantiated to create a new object of type abstractStudent with new keyword
        
        // Employer employer = new Employer();
        //Employer is interface and can not instantiated to create a object of the type employer with new keyword
        
        // Employee employee = new Employee();
        //Employee is interface and can not instantiate to create new object of type employee with new keyword
        
        System.out.println("Print Student Type Reference Variable");
        Student student = new Student("Calton", 2250.0, 3, "NWMSU", 10, 3.65, 10);
        System.out.println(student);

        System.out.println("Print AbstractStudent Type Reference Variable");
        AbstractStudent abstractStudent = new Student("Alex", 2300.0, 3, "UHCL", 14, 7.65, 5);
        System.out.println(abstractStudent);

        System.out.println("Print Employee Type Reference Variable");

        Employee employee = new Student("Kara", 3600.0, 2, "UCM", 12, 8.85, 20);
        System.out.println(employee);
        
        System.out.println("Print Employer Type Reference Variable");
        
        Employer employer = new Student("Adam", 3250.0, 4, "UMKC", 9, 4.32, 50);
        System.out.println(employer);

        System.out.println(" ");

        System.out.println("Using Student Type Reference Variable");
        System.out.println("Total Tuition Fee: $" + student.getTuition());
        System.out.println("Salary for one week: $" + student.getWeeklySalary());
        System.out.println("Number of Employees: " + student.getNumOfEmployees());
        student.setNumOfEmployees(22);
        System.out.println("Updated number of Employees: " + student.getNumOfEmployees());

        System.out.println("");

        System.out.println("Using AbstractStudent Type Reference Variable");
        System.out.println("Total Tuition Fee: $" + abstractStudent.getTuition());
        
        
        //System.out.println("Salary for one week: $" + abstractStudent.getWeeklySalary());
      //AstractStudent abstract calss did not have method getWeeklySalary so when we try to call the method we get error
        
        // System.out.println("Number of Employees: " + abstractStudent.getNumOfEmployees());
       //AstractStudent abstract class did not have method getNumOfEmployees so when we try to call the method we get error
        
        //abstractStudent.setNumOfEmployees(60);
        //AstractStudent abstract calss did not have method setNumOfEmployees so when we try to call the method we get error
        
        System.out.println(" ");

        System.out.println("Using Employee Type Reference Variable");
        
        // System.out.println("Total Tuition Fee: $" + employee.getTuition());
        //Student concrete calss has method getTution so when we try to call the method with other interface employee which do not have getTuition we get error 
        
        System.out.println("Salary for one week: $ " + Math.nextUp(employee.getWeeklySalary()));
        
        //System.out.println("Number of Employees: " + employee.getNumOfEmployees());
        //Employer interface has method getNumofEmployees so when we try to call the method with other interface employee which do not have getNumOfEmployees we get error 
        
        // employee.setNumOfEmployees(60);
        //calling setNumOfEmployees using interface employee reference which do not have the same method gives the error

        System.out.println(" ");

        System.out.println("Using Employer Type Reference Variable");
       
        // System.out.println("Total Tuition Fee: $" + employer.getTuition());
         //Employer interface did not have the method getTuition so we get error in the above line
       
        // System.out.println("Salary for one week: $" + employer.getWeeklySalary());
         //Employer interface did not have the method getWeeklySalary so when try to call the same from the Employer interface we get the error
        System.out.println("Number of Employees: " + employer.getNumOfEmployees());
        employer.setNumOfEmployees(60);
        System.out.println("Updated number of Employees: " + employer.getNumOfEmployees());

    }

}
