/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AbstractClassInterfaces;

/**
 *
 * @author Nagababu Rellacharla
 */
public class Student extends AbstractStudent implements Employee, Employer {

    private String nameInstitution;
    private int hoursWorked;
    private double hourlyRate;
    private int numOfEmployees;
    private int years;

    public Student(String nameStudent, double annualTuition, int years, String nameInstitution, int hoursWorked, double hourlyRate, int numOfEmployees) {
        super(nameStudent, annualTuition);
        this.nameInstitution = nameInstitution;
        this.hoursWorked = hoursWorked;
        this.hourlyRate = hourlyRate;
        this.numOfEmployees = numOfEmployees;
        this.years = years;
    }

    @Override
    public double getTuition() {
        double annualTuition = 0.0;
        annualTuition = getAnnualTuition() * years;
        return annualTuition;
    }

    @Override
    public double getWeeklySalary() {
        double weekSalary = 0.0;
        double weekSal = 0.0;
        weekSalary = hourlyRate * hoursWorked * 7;
        // weekSal =  Math.nextUp(weekSalary);
        return weekSalary;
    }

    @Override
    public int getNumOfEmployees() {
        return numOfEmployees;
    }

    @Override
    public void setNumOfEmployees(int numOfEmploye) {
        numOfEmployees = numOfEmploye;
    }

    @Override
    public String toString() {
        String retrunValue = String.format("%-20s %4d %10.2f %4d %4d", nameInstitution, hoursWorked, hourlyRate, years, numOfEmployees);

        return super.toString() + retrunValue;
    }

}
