/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package showdogs;

import java.util.ArrayList;

/**
 *
 * @author Nagababu Rellacharla
 */
public class ShowDogList {

    private ArrayList<ShowDog> dogList;

    public ShowDogList() {
        this.dogList = new ArrayList<>();

    }

    /**
     *
     * @param dg has one parameter dg of type ShowDog and returns nothing; the
     * dog passed as a parameter is added to dogList.
     */
    public void addShowDog(ShowDog dg) {
        dogList.add(dg);
    }

    /**
     *
     * @return returns the oldest show dog in the list.
     */
    public ShowDog oldestDog() {
        ShowDog olddog = dogList.get(0);
        int dogAge = dogList.get(0).ageOfDog();
        for (int i = 1; i < dogList.size(); i++) {
            if (dogAge < dogList.get(i).ageOfDog()) {
                olddog = dogList.get(i);
                dogAge = dogList.get(i).ageOfDog();
            }
        }
        return olddog;
    }

    /**
     *
     * @return returns the dog with the maximum number of points.
     */
    public ShowDog maxPoints() {
        ShowDog maxDog = dogList.get(0);
        int points = dogList.get(0).totalPoints();
        for (int i = 1; i < dogList.size(); i++) {
            if (points < dogList.get(i).totalPoints()) {
                maxDog = dogList.get(i);
            }
        }
        return maxDog;
    }

    /**
     *
     * @param ename of type String representing an event name.
     * @return This method returns the show dog with the most points in the
     * specified event.
     */
    public ShowDog mostPointsIn(String ename) {
        ShowDog dog1 = null;
        int maxpoints = 0;
        for (ShowDog sd : dogList) {
            ArrayList<EventPoints> edoglist = sd.getShowRecord();
            for (EventPoints ep : edoglist) {
                if (ep.getEventName().equals(ename)) {
                    if (maxpoints < ep.getPoints()) {
                        maxpoints = ep.getPoints();
                        dog1 = sd;
                    }
                }
            }
        }
        return dog1;
    }

    /**
     *
     * @return returns a string consisting of each dog’s name followed by a
     * space, followed by the age of the dog.
     */
    public String dogsAndAges() {
        String out = "";
        for (ShowDog dog3 : dogList) {
            out += dog3.getDogName() + " " + dog3.ageOfDog() + "\n";
        }
        return out;
    }

    @Override
    public String toString() {
        String outString = "";
        for (ShowDog dod : dogList) {
            outString += dod.toString() + "\n";
        }
        return outString;
    }

}
