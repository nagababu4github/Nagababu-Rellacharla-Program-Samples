/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package showdogs;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;

/**
 *
 * @author Nagababu Rellacharla
 */
public class ShowDog {

    private String dogID;
    private String dogName;
    private String breed;
    private LocalDate DOB;
    private ArrayList<EventPoints> showRecord;

    public ShowDog(String dogID, String dogName, String breed, LocalDate DOB) {
        this.dogID = dogID;
        this.dogName = dogName;
        this.breed = breed;
        this.DOB = DOB;
        this.showRecord = new ArrayList<>();
    }

    public void addEventPoints(EventPoints ep) {
        boolean isTrue = false;
        for (int i = 0; i < showRecord.size(); i++) {
            if ((showRecord.get(i).getEventName()).equals(ep.getEventName())) {
                showRecord.get(i).setPoints(ep.getPoints() + (showRecord.get(i).getPoints()));
                isTrue = true;
            }

        }
        if (isTrue == false) {
            showRecord.add(ep);
        }
    }

    public String getDogName() {
        return dogName;
    }

    public ArrayList<EventPoints> getShowRecord() {
        return showRecord;
    }

    public int ageOfDog() {
        int age = LocalDate.now().getYear() - DOB.getYear();
        if (LocalDate.now().getMonthValue() < DOB.getMonthValue()) {
            age = age - 1;
        } else if (LocalDate.now().getMonthValue() == DOB.getMonthValue()) {
            if (LocalDate.now().getDayOfMonth() < DOB.getDayOfMonth()) {
                age = age - 1;
            }
        }
        return age;
    }

    public int totalPoints() {
        int totalpoints = 0;
        for (int i = 0; i < showRecord.size(); i++) {
            totalpoints += showRecord.get(i).getPoints();
        }
        return totalpoints;
    }

    @Override
    public String toString() {
        String out = String.format("%-5s %-15s %-18s %10s", dogID, dogName, breed, DOB);
        return out;
    }

    public String toExtendedString() {
        String exString = toString() + "\n";
        for (int i = 0; i < showRecord.size(); i++) {
            exString += showRecord.get(i).toString() + "\n";
        }
        return exString;
    }

}
