/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package showdogs;

import java.io.File;
import java.io.FileNotFoundException;
import java.time.LocalDate;
import java.util.Scanner;

/**
 *
 * @author Nagababu Rellacharla
 */
public class ShowDogDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {

        ShowDogList myList = new ShowDogList();
        Scanner myScan = new Scanner(new File("showDogs.txt"));
        while (myScan.hasNext()) {
            String id = myScan.next();
            myScan.nextLine();
            String name = myScan.nextLine();
            String breed = myScan.nextLine();

            LocalDate dateOfBirth = LocalDate.parse(myScan.nextLine());
            ShowDog dogy = new ShowDog(id, name, breed, dateOfBirth);

            String eventName = myScan.next();
            while (!eventName.equals("*")) {
                int points = myScan.nextInt();
                EventPoints ep = new EventPoints(eventName, points);
                dogy.addEventPoints(ep);
                eventName = myScan.next();
            }
            myList.addShowDog(dogy);
            System.out.println("ADDED DOG TO myList");
            System.out.println(dogy.toExtendedString());
        }
        System.out.println("Contents of myList,using the toString method of myList");
        System.out.println(myList.toString());
        System.out.println("Dog with most total points, using method maxPoints:");
        System.out.println(myList.maxPoints());
        System.out.println("\nFind dog with most points in various events, using method mostPointsIn");
        String eventName = "Obedience";
        System.out.println("Dog with most points in obedience:\n" + myList.mostPointsIn(eventName));
        String eventName1 = "Conformation";
        System.out.println("Dog with most points in conformation:\n" + myList.mostPointsIn(eventName1));
        String eventName2 = "Agility";
        System.out.println("Dog with most points in agility:\n" + myList.mostPointsIn(eventName2));
        String eventName3 = "AdvancedAgility";
        System.out.println("Dog with most points in advanced agility:\n" + myList.mostPointsIn(eventName3));
        String eventName4 = "Rally";
        System.out.println("Dog with most points in rally:\n" + myList.mostPointsIn(eventName4));
        String eventName5 = "NoviceObedience";
        System.out.println("Dog with most points in novice obedience:\n" + myList.mostPointsIn(eventName5));
        String eventName6 = "NoviceRally";
        System.out.println("Dog with most points in novice rally:\n" + myList.mostPointsIn(eventName6));
        System.out.println("\nDogs and Ages, using method dogsAndAges:");
        System.out.println(myList.dogsAndAges());
        System.out.println("Oldest Dog, using method oldestDog:\n" + myList.oldestDog());
    }
}
