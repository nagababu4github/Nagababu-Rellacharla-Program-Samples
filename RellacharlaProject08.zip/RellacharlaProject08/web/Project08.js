/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function getPlanets() {
    clearPlanets();

    request = new XMLHttpRequest();
    var url = "SolarServlet?distance=" + document.getElementById("distance").value +
            "&diameter=" + document.getElementById("diameter").value + "&gravity=" + document.getElementById("gravity").value;
    request.open("GET", url, true);
    request.onreadystatechange = displayPlanets;
    request.send(null);
}
function clearPlanets() {
    var planetslist = document.getElementById("planets");
    while (planetslist.lastChild) {
        planetslist.removeChild(planetslist.lastChild);
    }
}
function displayPlanets() {

    if (request.readyState === 4 && request.status === 200) {
        var planets = request.responseXML.getElementsByTagName("planet");
        for (var i = 0; i < planets.length; i++) {
            var name = planets[i].getElementsByTagName("name")[0].firstChild.nodeValue;
            var distance = parseFloat(planets[i].getElementsByTagName("distance")[0].firstChild.nodeValue);
            var period = parseFloat(planets[i].getElementsByTagName("period")[0].firstChild.nodeValue);
            var diameter = parseFloat(planets[i].getElementsByTagName("diameter")[0].firstChild.nodeValue);
            var gravity = parseFloat(planets[i].getElementsByTagName("gravity")[0].firstChild.nodeValue);
            var mass = parseFloat(planets[i].getElementsByTagName("mass")[0].firstChild.nodeValue);
            var row = document.createElement("tr");
            var nameElement = document.createElement("td");
            nameElement.appendChild(document.createTextNode(name));
            row.appendChild(nameElement);
            var distanceElement = document.createElement("td");
            distanceElement.appendChild(document.createTextNode(distance));
            row.appendChild(distanceElement);
            var periodElement = document.createElement("td");
            periodElement.appendChild(document.createTextNode(period));
            row.appendChild(periodElement);
            var diameterElement = document.createElement("td");
            diameterElement.appendChild(document.createTextNode(diameter));
            row.appendChild(diameterElement);
            var massElement = document.createElement("td");
            massElement.appendChild(document.createTextNode(mass));
            row.appendChild(massElement);
            var gravityElement = document.createElement("td");
            gravityElement.appendChild(document.createTextNode(gravity));
            row.appendChild(gravityElement);
            document.getElementById("planets").appendChild(row);

        }

    }
}
window.onload = function () {
    document.getElementById("find").onclick = getPlanets;

};
