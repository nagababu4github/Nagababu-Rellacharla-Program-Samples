/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rellacharlalambdaexpressions;

import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.IntFunction;
import java.util.function.Predicate;

/**
 *
 * @author Nagababu Rellacharla
 */
public class RellacharlaLambdaExpressions {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        IntFunction<Integer> subtractThree = (int x) -> x - 3;
        System.out.println(subtractThree.apply(75));
        System.out.println();
        IntFunction<String> bigOrLittle = (int x) -> {
            if (x > 10) {
                return "big";
            } else {
                return "little";
            }
        };
        System.out.println(bigOrLittle.apply(10));
        System.out.println(bigOrLittle.apply(25));
        System.out.println();
        IntFunction<String> zeroOrOne = (int x) -> x == 0 ? "zero" : x == 1 ? "one" : "other";

        System.out.println(zeroOrOne.apply(0));
        System.out.println(zeroOrOne.apply(1));
        System.out.println(zeroOrOne.apply(12));
        System.out.println();
        Function<String, Character> lastCharacter = (String s) -> s.charAt(s.length() - 1);
        System.out.println(lastCharacter.apply("Northwest"));
        System.out.println(lastCharacter.apply("X"));
        System.out.println();
        BiFunction<String, Integer, String> findSubstring = (String s1, Integer n) -> s1.substring(n);

        System.out.println(findSubstring.apply("Northwest", 5));
        System.out.println(findSubstring.apply("LambdaExpressions", 6));
        Predicate<String> isPalindrome = (String s) -> {
            boolean palindrome = true;
            for (int i = 0; i < (s.length()) / 2; i++) {
                if (s.charAt(i) != s.charAt(s.length() - i - 1)) {
                    palindrome = false;
                    break;
                }

            }
            return palindrome;
        };
        System.out.println();
        System.out.println(isPalindrome.test("radar"));
        System.out.println(isPalindrome.test("x"));
        System.out.println(isPalindrome.test("wasitacaroracatisaw"));
        System.out.println(isPalindrome.test("notapalindrome"));
        System.out.println(isPalindrome.test("xy"));
    }
}
