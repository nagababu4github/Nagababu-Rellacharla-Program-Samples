/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package climatechange;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author Nagababu Rellacharla
 */
public class IceMassDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        Scanner myScan = new Scanner(new File("iceMass.txt"));
        while (myScan.hasNext()) {
            String name = myScan.next();
            int area = myScan.nextInt();
            double thickness = myScan.nextDouble();
            double initialMeltRate = myScan.nextDouble();

            IceMass myIceMass = new IceMass(name, area, thickness, initialMeltRate);

            double totalRise = myIceMass.totalRiseInSeaLevel();

            System.out.printf("Years until the %s ice sheet melts: %d\n ", myIceMass.getName(), myIceMass.yearsUntil(totalRise));
            System.out.printf("If the %s ice sheet melts, sea levels will rise %.2f feet \n", myIceMass.getName(), totalRise);
            System.out.println("One-tenth of the total possible rise: " + 0.1 * totalRise);

            System.out.printf("Years until the increase in sea level from the melting of %s is equal to 1/10 the possible rise: %d\n ", myIceMass.getName(), myIceMass.yearsUntil(0.1 * totalRise));
            System.out.println();
        }
        myScan.close();

    }

}
