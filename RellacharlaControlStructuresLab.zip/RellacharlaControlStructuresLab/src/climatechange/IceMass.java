/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package climatechange;

/**
 * This class is used to create appropriate methods and calculate the necessary
 * years
 *
 * @author Nagababu Rellacharla
 */
public class IceMass {

    private final double CONVERSION_FACTOR = 0.0002 / 12.0;
    private String name;
    private int area;
    private double thickness;
    private double initialMeltRate;

    public IceMass(String name, int area, double thickness, double initialMeltRate) {
        this.name = name;
        this.area = area;
        this.thickness = thickness;
        this.initialMeltRate = initialMeltRate;
    }

    /**
     *
     * @return Name of ice mass
     */
    public String getName() {
        return name;
    }

    /**
     *
     * @return Rise of sea level for total ice mass melt
     */
    public double totalRiseInSeaLevel() {
        double riseInSeaLevel = 0.0;
        riseInSeaLevel = (area * thickness) * CONVERSION_FACTOR;
        return riseInSeaLevel;
    }

    /**
     *
     * @param param1 rise in sea level for ice mass melting
     * @return years required for rise in sea level to given param1 (in feet)
     */
    public int yearsUntil(double param1) {

        int i = 0;
        double meltRate = initialMeltRate;
        double riseInLevel = 0;
        while (riseInLevel < param1) {
            if (i < 10) {
                riseInLevel = riseInLevel + meltRate * CONVERSION_FACTOR;
            } else {
                meltRate = meltRate * 2;
                riseInLevel += meltRate * CONVERSION_FACTOR;
            }
            i++;
        }

        return i;
    }

}
