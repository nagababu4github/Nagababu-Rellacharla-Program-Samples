package wordgames;

import java.util.ArrayList;

/**
 *
 * @author Nagababu Rellacharla
 */
public class WordGames {

    private ArrayList<String> wordList;

    public WordGames() {
        wordList = new ArrayList<String>();
    }

    public void addWord(String word) {
        wordList.add(word);
    }

    public int numberOfWords() {
        return wordList.size();
    }

    /**
     * Returns an array list of all the words in wordList such that if you
     * remove the first letter, the remaining letters form a word that is also
     * in wordList. Example: "place" would be included in the array list because
     * "lace" is also in wordList. "aardvark" would not be included in the array
     * list because "ardvark" is not in wordList.
     *
     * @return an array list of all the words in wordList such that if you
     * remove the first letter, the remaining letters form a word that is also
     * in wordList.
     */
    public ArrayList<String> beheadment() {
        ArrayList<String> returnValue = new ArrayList<>();
        String firstLetterWord = "";
        for (String s : wordList) {
            firstLetterWord = s.substring(1);
            if (wordList.contains(firstLetterWord)) {
                returnValue.add(s);
            }

        }
        return returnValue;
    }

    /**
     * Returns a string representing the number sent as an argument. If the
     * number is divisible by 5, "buzz" is returned. If it is not divisible by
     * 5, then a string of characters matching the digits of the number are
     * returned, with the number 5 replaced by "buzz". Example: For the number
     * 550, "buzz" is returned. For the number 551351, the string "buzz buzz 1 3
     * buzz 1" is returned.
     *
     * Hint: To convert an integer to a String, use the Integer.toString method.
     * Example: If num is an int value, then Integer.toString(num) returns the
     * string representation of num.
     *
     * @param numberIn The number that we are converting to a string.
     * @return a string representing the number sent as an argument, using the
     * rules described above.
     */
    public String buzzWords(int numberIn) {
        String returnValue = "";
        if (numberIn % 5 == 0) {
            returnValue = "buzz";
        } else {
            String intString = Integer.toString(numberIn);
            for (int i = 0; i < intString.length(); i++) {
                String letter = Character.toString(intString.charAt(i));
                if (Integer.parseInt(letter) == 5) {
                    returnValue += "buzz ";
                } else {
                    returnValue += intString.charAt(i) + " ";
                }
            }
        }
        return returnValue;
    }

    /**
     * Returns an array list of all words in wordList that are "summer
     * equivalent" to the argument. Two words are summer equivalent if the sum
     * of their characters are equal (where 'a' = 0, 'b' = 1, 'c' = 2, ..., 'z'
     * = 25). For example, "cab" and "ad" are summer equivalent, because 2 + 0 +
     * 1 = 0 + 3.
     *
     * Note: You may assume that only lowercase letters appear in words in
     * wordList and in word.
     *
     * Hint: If we have a variable ch of type char, and if ch has a lowercase
     * letter as its value, then ch - 'a' will return the numeric equivalent (as
     * described above for summer equivalent words) of the lowercase letter.
     *
     * @param myWord The word for which we are trying to find all summer
     * equivalent words.
     * @return an array list of all words in wordList that are "summer
     * equivalent" to the argument using the rules described above.
     */
    public ArrayList<String> findSummerWords(String myWord) {
        int SummerValue = 0;
        ArrayList<String> returnList = new ArrayList<>();
        int summerVlaueWordlist = 0;
        for (int i = 0; i < myWord.length(); i++) {
            SummerValue += myWord.charAt(i) - 97;
        }
        for (String s : wordList) {
            summerVlaueWordlist = 0;
            for (int i = 0; i < s.length(); i++) {
                summerVlaueWordlist += s.charAt(i) - 97;
                if (summerVlaueWordlist == SummerValue) {
                    returnList.add(s);
                }
            }

        }
        return returnList;
    }

    /**
     * Returns an array list of all words in wordList that are nested in the
     * argument. One word is nested in a second word if the first word is a
     * substring of the second word. Example: For the word "battery", nested
     * words are "at", "bat", "batter", and "battery".
     *
     * @param myWord The word for which we are trying to find all nested words.
     * @return an array list of all words in wordList that are nested in the
     * argument.
     */
    public ArrayList<String> findNestedWords(String myWord) {
        ArrayList<String> returnList = new ArrayList<>();
        String nestedWord = "";
        for (String s : wordList) {
            if (myWord.contains(s)) {
                returnList.add(s);
            }

        }
        return returnList;
    }

    /**
     * Returns an array list of all words in wordList, such that the reverse of
     * the word is also in wordList.
     *
     * @return an array list of all words in wordList, such that the reverse of
     * the word is also in wordList
     */
    public ArrayList<String> findReversibleWords() {
        ArrayList<String> returnList = new ArrayList<>();
        String reverse = "";
        for (String s : wordList) {
            reverse = "";
            for (int i = s.length() - 1; i >= 0; i--) {
                reverse += s.charAt(i);
            }
            if (wordList.contains(reverse)) {
                returnList.add(s);
//                    returnList.add(reverse);
            }
        }
        return returnList;
    }

    /**
     * Return an array list of words satisfying the rules of this version of
     * Acrostics. Begin with myWord and list it forwards and backwards. For
     * example, if myWord is canyon, we would have: canyon noynac Looking at
     * vertical pairs of letters from left to right, we would first find the
     * longest word in wordList that begins with a "c" and ends with an "n".
     * That word would be added to the array list. Then we would find the
     * longest word in wordList that begins with an "a" and ends with an "o";
     * then the longest word in wordlist that begins with an "n" and ends with a
     * "y"; and so on for each pair of letters. For this example, we will have
     * at most six words in the array list, since there are six letters in the
     * word "canyon". There can be fewer than six words if no such word exists
     * for a given pair of letters.
     *
     * @param myWord This word is the starting point for Acrostics, as defined
     * above.
     * @return an array list of words satisfying the rules of this version of
     * Acrostics.
     */
    public ArrayList<String> acrostics(String myWord) {
        ArrayList<String> returnValue = new ArrayList<>();
        for (int i = 0, j = myWord.length() - 1; j >= 0 && i < myWord.length(); i++, j--) {
            String word = "";
            int length = 0;
            for (String s : wordList) {
                if (s.startsWith(Character.toString(myWord.charAt(i))) && s.endsWith(Character.toString(myWord.charAt(j)))) {
                    if (length < s.length()) {
                        length = s.length();
                        word = s;
                    }

                }
            }
            returnValue.add(word);
        }

        return returnValue;
    }
}
