package wordgames;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class WordGamesDriver {

    public static void main(String[] args) throws FileNotFoundException {
        Scanner in = new Scanner(new File("dictionary.txt"));
        Scanner kb = new Scanner(System.in);

        WordGames myGames = new WordGames();
        while (in.hasNext()) {
            myGames.addWord(in.next());
        }
        System.out.println(myGames.numberOfWords()
                + " words added to myGames");
        in.close();
        System.out.println();

        ArrayList<String> beheadmentList = myGames.beheadment();
        System.out.println(beheadmentList.size() + " words in "
                + "beheadment list");

        for (String word : beheadmentList) {
            System.out.println(word);
        }
        System.out.println();

        System.out.println("Buzz words");
        System.out.println("5543551: " + myGames.buzzWords(5543551));
        System.out.println("5543550: " + myGames.buzzWords(5543550));
        System.out.println();

        ArrayList<String> mySummerWords
                = myGames.findSummerWords("place");
        System.out.println(mySummerWords.size()
                + " summer words for place");
        for (String summerWord : mySummerWords) {
            System.out.println(summerWord);
        }
        System.out.println();

        ArrayList<String> myNestedWords
                = myGames.findNestedWords("battery");
        System.out.println(myNestedWords.size()
                + " words nested in battery");

        for (String nestedWord : myNestedWords) {
            System.out.println(nestedWord);
        }
        System.out.println();

        ArrayList<String> myReversibleWords
                = myGames.findReversibleWords();
        System.out.println(myReversibleWords.size()
                + " reversible words");

        for (String reversibleWord : myReversibleWords) {
            System.out.println(reversibleWord);
        }
        System.out.println();

        ArrayList<String> myAcrosticsList = myGames.acrostics("canyon");
        System.out.println("Acrostics list for canyon: "
                + myAcrosticsList.size());
        for (String myWord : myAcrosticsList) {
            System.out.println(myWord);
        }
        System.out.println();

        myAcrosticsList = myGames.acrostics("ate");
        System.out.println("Acrostics list for ate: "
                + myAcrosticsList.size());
        for (String myWord : myAcrosticsList) {
            System.out.println(myWord);
        }
        System.out.println();
    }
}
