/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function orderTotal() {
    var price = 0.00;
    PLAIN_CONE = 0.30;
    WAFFLE_CONE = 0.50;
    CUP = 0.20;
    EACH_SCOOP = 0.75;
    SPRINKLE = 0.25;
    CARAMEL_GOO = 0.35;
    CHOCOLATE_SAUCE = 0.40;
    CHOPPED_WALNUT = 0.45;
    var isAllDataEntered = true;
    var error = "";
    //Checking whether cone or cup is selected and calcualting price
    if (document.getElementById("planeCone").checked) {
        price += PLAIN_CONE;
    }
    else if (document.getElementById("waffleCone").checked) {
        price += WAFFLE_CONE;
    }
    else if (document.getElementById("cup").checked) {
        price += CUP;
    }
    else
    {
        isAllDataEntered = false;
        error = "Select cone or cup.<br>";
    }
    //Selecting Flavor
    if (document.getElementById("flavorType").value == "chooseFlavour") {
        error += "Select flavor. <br>";
        isAllDataEntered = false;
    }
//Checking for number of scoops
    if (document.getElementById("one").checked) {
        price += EACH_SCOOP;
    }
    else if (document.getElementById("two").checked) {
        price += 2 * EACH_SCOOP;
    }
    else if (document.getElementById("three").checked) {
        price += 3 * EACH_SCOOP;
    }
    else
    {
        isAllDataEntered = false;
        error += "Select the number of scoops.<br>";
    }
//Calculating price for extras
    if (document.getElementById("sprinkels").checked) {
        price += SPRINKLE;
    }
    if (document.getElementById("caramelGoo").checked) {
        price += CARAMEL_GOO;
    }
    if (document.getElementById("chocolateSauce").checked) {
        price += CHOCOLATE_SAUCE;
    }
    if (document.getElementById("choppedWalnuts").checked) {
        price += CHOPPED_WALNUT;
    }

    if (document.getElementById("name").value == "") {
        isAllDataEntered = false;
        error += "Enter your name.<br> ";
    }

    if (isAllDataEntered == false) {
        document.getElementById("orderDetails").innerHTML = "";
        document.getElementById("errorNam").innerHTML = error;
    }
    else
    {
        document.getElementById("errorNam").innerHTML = "";
        document.getElementById("orderDetails").innerHTML = "Your " + document.getElementById("flavorType").value + " ice cream will be ready soon, " +
                document.getElementById("name").value + ".<br> Your order total is $" + price.toFixed(2) + ".";
    }
}
window.onload = function () {
    document.getElementById("order").onclick = orderTotal;
};