/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var total = 0.0;
function getMessage() {
    request = new XMLHttpRequest();
    var url = "getOrderServlet?itemType=" + document.getElementById("itemType").value;
    request.open("GET", url, true); // Second parameter is URL of servlet
    request.onreadystatechange = displayAdded;
    request.send(null);
}
function displayAdded() {

    document.getElementById("added").innerHTML = "Added " + document.getElementById("itemType").value;

    if (request.readyState === 4 && request.status === 200) {
        var price1 = parseFloat(request.responseText);
        total += document.getElementById("quantity").value * price1;
        document.getElementById("quantity").value = "";
    }



}
function placeOrder() {

    document.getElementById("msg").innerHTML = "<h3>Your order total is $" + total.toFixed(2) + "</h3>";
    total = 0.0;

}





window.onload = function () {
    document.getElementById("placeOrder").onclick = placeOrder;
    document.getElementById("add").onclick = getMessage;

}
