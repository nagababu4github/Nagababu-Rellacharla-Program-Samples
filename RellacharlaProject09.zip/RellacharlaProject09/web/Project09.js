/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function getPlanets() {
    $('#planets').empty();
    $.getJSON("SolarJSONServlet?distance=" + $('#distance').val() +
            "&diameter=" + $('#diameter').val() + "&gravity=" + $('#gravity').val(), displayPlanets);
}

function displayPlanets(data) {

    $.each(data.planet,
            function () {
                $('#planets').append("<tr>"
                        + "<td>" + this.name + "</td>"
                        + "<td>" + this.distance + "</td>"
                        + "<td>" + this.period + "</td>"
                        + "<td>" + this.diameter + "</td>"
                        + "<td>" + this.mass + "</td>"
                        + "<td>" + this.gravity + "</td>");
            });
}


$(document).ready(
        function () {
            $('#find').click(getPlanets);

        }
);
