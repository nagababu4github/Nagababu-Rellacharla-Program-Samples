/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package circlecalculations;

import javax.inject.Named;
import javax.enterprise.context.RequestScoped;

/**
 *
 * @author Nagababu Rellacharla
 */
@Named(value = "circleBean")
@RequestScoped
public class CircleBean {

    double radius;

    /**
     * Creates a new instance of CircleBean
     */
    public CircleBean() {
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public double getCircumference() {
        return 2 * Math.PI * radius;
    }

    public double getArea() {
        return Math.PI * radius * radius;
    }

    public double getSqareCircumference() {
        double squareSide = 2 * radius;
        return 4 * squareSide;
    }

    public double getSquareArea() {
        double squareSide = 2 * radius;
        return squareSide * squareSide;
    }

    public double getOuterCircumference() {
        double squareDiagnol = Math.sqrt(2 * radius * radius);
        return 2 * Math.PI * squareDiagnol;
    }

    public double getOuterreArea() {
        double squareDiagnol = Math.sqrt(2 * radius * radius);
        return Math.PI * squareDiagnol * squareDiagnol;
    }

}
