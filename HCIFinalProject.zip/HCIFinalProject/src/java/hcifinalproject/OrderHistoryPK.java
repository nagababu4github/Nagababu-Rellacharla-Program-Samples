/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hcifinalproject;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author S522618
 */
@Embeddable
public class OrderHistoryPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "SONG_ID")
    private int songId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "USER_ID")
    private int userId;

    public OrderHistoryPK() {
    }

    public OrderHistoryPK(int songId, int userId) {
        this.songId = songId;
        this.userId = userId;
    }

    public int getSongId() {
        return songId;
    }

    public void setSongId(int songId) {
        this.songId = songId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) songId;
        hash += (int) userId;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof OrderHistoryPK)) {
            return false;
        }
        OrderHistoryPK other = (OrderHistoryPK) object;
        if (this.songId != other.songId) {
            return false;
        }
        if (this.userId != other.userId) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hcifinalproject.OrderHistoryPK[ songId=" + songId + ", userId=" + userId + " ]";
    }
    
}
