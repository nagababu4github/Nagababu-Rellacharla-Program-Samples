/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hcifinalproject;

import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;

/**
 *
 * @author Nagababu Rellacharla
 */
@ManagedBean
@RequestScoped
public class reviewBean {
private String avgrating;
private String reviewSubject;
private String reviewcomments;
  @PersistenceUnit(unitName = "HCIFinalProjectPU")
   private EntityManagerFactory emf = null;
    /**
     * Creates a new instance of reviewBean
     */
    public reviewBean() {
    }

    public String getAvgrating() {
        return avgrating = "4.5/5.0";
    }

    public String getReviewSubject() {
        return reviewSubject ="This is good song";
    }

    public String getReviewcomments() {
        return reviewcomments;
    }

    public void setAvgrating(String avgrating) {
        this.avgrating = avgrating;
    }

    public void setReviewSubject(String reviewSubject) {
        this.reviewSubject = reviewSubject;
    }

    public void setReviewcomments(String reviewcomments) {
        this.reviewcomments = reviewcomments;
    }
   
       public List<UserSongRate> getReviews(){
            EntityManager em = emf.createEntityManager();
                           List<UserSongRate> sl= (em.createNamedQuery(
            "UserSongRate.findAll").getResultList());
                           
                                                              
                           return sl;
                           
                           
    }
         public List<OrderHistory> getOrderHostory(){
            EntityManager em = emf.createEntityManager();
                           List<OrderHistory> sl= (em.createNamedQuery(
            "OrderHistory.findAll").getResultList());
                                    return sl;
         }
        // UserSongRate us = new UserSongRate(avgrating, reviewcomments);
    
}
