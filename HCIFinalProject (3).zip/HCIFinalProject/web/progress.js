
function review() {    
    document.getElementById("com").style.visibility = 'visible';
    document.getElementById("com1").style.visibility = 'visible';

}

window.onload = function () {
    document.getElementById("write").onclick = review;
    document.getElementById("userId").value = "Nagababu";
  
};
        