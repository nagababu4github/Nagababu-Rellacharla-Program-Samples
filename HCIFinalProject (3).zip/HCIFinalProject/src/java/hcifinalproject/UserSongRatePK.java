/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hcifinalproject;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author S522618
 */
@Embeddable
public class UserSongRatePK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "USER_ID")
    private int userId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "SONG_ID")
    private int songId;

    public UserSongRatePK() {
    }

    public UserSongRatePK(int userId, int songId) {
        this.userId = userId;
        this.songId = songId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getSongId() {
        return songId;
    }

    public void setSongId(int songId) {
        this.songId = songId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) userId;
        hash += (int) songId;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof UserSongRatePK)) {
            return false;
        }
        UserSongRatePK other = (UserSongRatePK) object;
        if (this.userId != other.userId) {
            return false;
        }
        if (this.songId != other.songId) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hcifinalproject.UserSongRatePK[ userId=" + userId + ", songId=" + songId + " ]";
    }
    
}
