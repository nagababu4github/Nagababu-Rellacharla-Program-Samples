/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hcifinalproject;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author S522618
 */
@Entity
@Table(name = "ORDER_HISTORY")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "OrderHistory.findAll", query = "SELECT o FROM OrderHistory o"),
    @NamedQuery(name = "OrderHistory.findBySongId", query = "SELECT o FROM OrderHistory o WHERE o.orderHistoryPK.songId = :songId"),
    @NamedQuery(name = "OrderHistory.findByUserId", query = "SELECT o FROM OrderHistory o WHERE o.orderHistoryPK.userId = :userId"),
    @NamedQuery(name = "OrderHistory.findBySongTitle", query = "SELECT o FROM OrderHistory o WHERE o.songTitle = :songTitle"),
    @NamedQuery(name = "OrderHistory.findByDate", query = "SELECT o FROM OrderHistory o WHERE o.date = :date"),
    @NamedQuery(name = "OrderHistory.findByOrderTotal", query = "SELECT o FROM OrderHistory o WHERE o.orderTotal = :orderTotal"),
    @NamedQuery(name = "OrderHistory.findByQuality", query = "SELECT o FROM OrderHistory o WHERE o.quality = :quality")})
public class OrderHistory implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected OrderHistoryPK orderHistoryPK;
    @Size(max = 50)
    @Column(name = "SONG_TITLE")
    private String songTitle;
    @Column(name = "DATE")
    @Temporal(TemporalType.DATE)
    private Date date;
    @Column(name = "ORDER_TOTAL")
    private Integer orderTotal;
    @Size(max = 50)
    @Column(name = "QUALITY")
    private String quality;

    public OrderHistory() {
    }

    public OrderHistory(OrderHistoryPK orderHistoryPK) {
        this.orderHistoryPK = orderHistoryPK;
    }

    public OrderHistory(int songId, int userId) {
        this.orderHistoryPK = new OrderHistoryPK(songId, userId);
    }

    public OrderHistoryPK getOrderHistoryPK() {
        return orderHistoryPK;
    }

    public void setOrderHistoryPK(OrderHistoryPK orderHistoryPK) {
        this.orderHistoryPK = orderHistoryPK;
    }

    public String getSongTitle() {
        return songTitle;
    }

    public void setSongTitle(String songTitle) {
        this.songTitle = songTitle;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Integer getOrderTotal() {
        return orderTotal;
    }

    public void setOrderTotal(Integer orderTotal) {
        this.orderTotal = orderTotal;
    }

    public String getQuality() {
        return quality;
    }

    public void setQuality(String quality) {
        this.quality = quality;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (orderHistoryPK != null ? orderHistoryPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof OrderHistory)) {
            return false;
        }
        OrderHistory other = (OrderHistory) object;
        if ((this.orderHistoryPK == null && other.orderHistoryPK != null) || (this.orderHistoryPK != null && !this.orderHistoryPK.equals(other.orderHistoryPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hcifinalproject.OrderHistory[ orderHistoryPK=" + orderHistoryPK + " ]";
    }
    
}
