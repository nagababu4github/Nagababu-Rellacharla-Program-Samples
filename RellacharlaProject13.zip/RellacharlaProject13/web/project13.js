/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function getProducts() {

    $("#results").empty();
    var itemType = $("#itemType").val();
    if (itemType === "none") {
        $("#error").html("Select a prodcut category");
         $("#error").show();
        $("#table").hide();
    }
    else {
        $("#error").hide();
        var uri = "http://localhost:8080/RellacharlaProject13/webresources/project13"
                + "?category=" + itemType;
        $.getJSON(uri, display);
    }
}

//*******************the json callback function has the parameter and the parameter is the value of response


function display(students) {
    $("#table").show();
    $.each(students.Products,
            function () {
                $('#results').append("<tr>"
                        + "<td>" + this.description + "</td>"
                        + "<td>" + this.quantity + "</td>"
                        + "</tr>");
            });
}

$(document).ready(
        function () {
            $("#table").hide();
            $('#find').click(getProducts);
        }
);
