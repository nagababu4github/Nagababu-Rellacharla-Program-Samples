package precip;

import java.util.*;

/**
 *
 * @author Nagababu Rellacharla
 */
public class Precip {

    /**
     * Key values in this tree map are city names; corresponding values are
     * lists of integers representing monthly precipitation amounts.
     */
    private TreeMap<String, ArrayList<Integer>> precipitation;

    /**
     * Constructor Sets precipitation to a new empty tree map with Strings as
     * keys and array lists of integers as values.
     */
    public Precip() {
        precipitation = new TreeMap<>();
    }

    /**
     * Returns the cities from the tree map.
     *
     * @return the cities from the tree map.
     */
    public Set<String> getCities() {
        return precipitation.keySet();
    }

    /**
     * Returns a String representation of this Precip object. The String
     * representation consists of the name of the city followed by a list of the
     * precipitation amounts. When printed, columns should be aligned as shown
     * in the sample output. Note that for your data set, all cities have the
     * same number of precipitation amounts, but this may not be true of all
     * data sets. We may test using a data set where different cities have lists
     * of different lengths.
     *
     * @return a String representation of this Precip object.
     */
    @Override
    public String toString() {
        //this.toString();
        String out = "";
        String city = "";
        //String sl = String.format("-20s", city);
        ArrayList<Integer> values = null;
        Set<String> cities = getCities();
        for (String s : cities) {
            city = s;
            out += String.format("%-20s", city);
            values = precipitation.get(s);
            for (Integer i : values) {
                out += String.format("%4d", i);
            }
            out += "\n";

        }

        return out;
    }

    /**
     * For each city in the tree map, this method sorts the corresponding
     * precipitation amounts in ascending order.
     */
    public void sortPrecipAmounts() {

        Set<String> cities = getCities();
        for (String s : cities) {
            ArrayList<Integer> values = precipitation.get(s);
            Collections.sort(values);

        }
    }

    /**
     * This method adds a precipitation amount to the tree map for the specified
     * city. If the city is not already in the tree map, it will be added to the
     * tree map.
     *
     * @param cityName
     * @param precipAmount
     */
    public void addPrecipAmount(String cityName, int precipAmount) {
        if (precipitation.containsKey(cityName)) {
            precipitation.get(cityName).add(precipAmount);
        } else {
            ArrayList<Integer> newcity = new ArrayList<>();
            newcity.add(precipAmount);
            precipitation.put(cityName, newcity);
        }
    }

    /**
     * This method returns the set of state and country names from the tree map.
     * Every city name is written with an initial capital letter, followed by
     * lowercase letters and NO spaces, except at the end of the city name,
     * where the state or country abbreviation is included, all in caps. For
     * example, El Paso, TX would be written as ElpasoTX;
     *
     * @return the set of state and country names from the tree map.
     */
    public Set<String> statesAndCountries() {
        Set<String> cities = getCities();
        TreeSet<String> out = new TreeSet<>();

        for (String s : cities) {

            String state = "";
            char citynamefirst = s.charAt(0);
            for (int i = 1; i < s.length(); i++) {
                if (Character.isUpperCase(s.charAt(i))) {
                    state = state + s.charAt(i);

                }

            }

            out.add(state);
        }
        return out;
    }

    /**
     * This method returns an array list of city names for those cities that
     * have at least one month with precipitation at least that of the argument.
     *
     * @param precipAmount
     * @return
     */
    public ArrayList<String> monthWithPrecipAtLeast(int precipAmount) {
        ArrayList<String> out = new ArrayList<>();
        ArrayList<Integer> amounts = new ArrayList<>();
        Set<String> cities = getCities();
        for (String s : cities) {
            amounts = precipitation.get(s);
            for (Integer i : amounts) {
                if (i >= precipAmount) {
                    out.add(s);
                    break;
                }
            }
        }
        return out;
    }

    /**
     * This method returns a String consisting of the name of the city that has
     * the most total precipitation and the number of inches in the total.
     *
     * @return
     */
    public String mostPrecip() {
        Set<String> cities = getCities();
        String returnCity = "";

        int mostTotal = 0;
        for (String s : cities) {
            int totalPrecipitation = 0;
            ArrayList<Integer> amounts = precipitation.get(s);
            for (Integer i : amounts) {
                totalPrecipitation += i;
            }
            if (totalPrecipitation >= mostTotal) {
                mostTotal = totalPrecipitation;
                returnCity = s;
            }
        }
        return returnCity + "has the most rainfall with a total of " + mostTotal + " inches.";
    }

    /**
     * This method returns an int value representing the longest contiguous
     * sequence of equal values in rainfall amounts for the city specified by
     * the argument.
     *
     * @param cityName The city for which we are looking at rainfall amounts.
     * @return length of the longest contiguous sequence of equal values in
     * rainfall amounts for the city specified.
     */
    public int longestEqualSequence(String cityName) {
        Set<String> cities = getCities();
        int out = 1;
        int returnout = 0;
        ArrayList<Integer> sameDigits = new ArrayList<>();

        ArrayList<Integer> amounts = precipitation.get(cityName);
        for (int i = 0; i < amounts.size() - 1; i++) {

            if (amounts.get(i) == amounts.get(i + 1)) {
                out++;

            } else {
                sameDigits.add(out);
                out = 1;

            }

        }
        sameDigits.add(out);

        for (int i = 0; i < sameDigits.size(); i++) {
            if (sameDigits.get(i) >= returnout) {
                returnout = sameDigits.get(i);

            }
        }

        return returnout;
    }
}
