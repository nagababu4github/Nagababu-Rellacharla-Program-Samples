package precip;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Set;

/**
 *
 * @author Nagababu Rellacharla
 */
public class PrecipDriver {

    public static void main(String[] args) throws FileNotFoundException {
        // Do not alter these two lines of code.
        Precip myPrecipData = new Precip();
        Scanner in = new Scanner(new File("precip.txt"));

      // INSERT CODE HERE TO READ IN DATA AND ADD TO myPrecipData.
        // Each line in the data set consists of a city name, followed
        // by a list of precipitation amounts. The number of lines of
        // data may vary.  In a single data set, the number of 
        // precipitation amounts for different cities may vary.
      // Here is a suggestion for reading the data and adding to
        // myPrecipData.  
        //  While there is data to be read
        //     Read in a line of data using nextLine
        //     Use split to place the data in a String array
        //     The first item in the array is the city name.
        //     Parse the remainder of the line to get integer 
        //       amounts of rainfall; as you find each amount
        //       use the addPrecipAmount method to add to myPrecipData
        while (in.hasNext()) {

            String line = in.nextLine();
            String[] linevalues = line.split(" ");
            String cityName = linevalues[0];
            for (int j = 1; j < linevalues.length; j++) {
                myPrecipData.addPrecipAmount(cityName, Integer.parseInt(linevalues[j]));
            }
        }

      //DO NOT ALTER ANY OF THE REMAINING CODE
        System.out.println("INITIAL DATA");
        System.out.println(myPrecipData);
        System.out.println();
        System.out.println(myPrecipData.mostPrecip());
        System.out.println();

        System.out.println("LONGEST SEQUENCE OF EQUAL VALUES");
        System.out.println("PRECIPITATION DATA IS NOT SORTED");
        Set<String> cities = myPrecipData.getCities();
        for (String city : cities) {
            System.out.println("The longest sequence of equal values "
                    + "in precipitation amounts for " + city + " is "
                    + myPrecipData.longestEqualSequence(city));
        }
        System.out.println();

        for (int i = 3; i < 8; i++) {
            String str = "Cities with precipitation of at least "
                    + i + " inches for at least one month:\n"
                    + myPrecipData.monthWithPrecipAtLeast(i);
            System.out.println(str);
            System.out.println();
        }
        System.out.println();

        Set<String> statesAndCountries
                = myPrecipData.statesAndCountries();

        System.out.println(statesAndCountries);
        System.out.println();

        System.out.println("INITIAL DATA");
        System.out.println("PRECIPITATION AMOUNTS ARE NOT SORTED");
        System.out.println(myPrecipData);
        System.out.println("");

        myPrecipData.sortPrecipAmounts();

        System.out.println("PRECIPITATION AMOUNTS ARE SORTED");
        System.out.println(myPrecipData);
        System.out.println();

        System.out.println("LONGEST SEQUENCE OF EQUAL VALUES");
        System.out.println("PRECIPITATION DATA IS SORTED");
        cities = myPrecipData.getCities();
        for (String city : cities) {
            System.out.println("The longest sequence of equal values "
                    + "in precipitation amounts for " + city + " is "
                    + myPrecipData.longestEqualSequence(city));
        }
        System.out.println();
    }
}
