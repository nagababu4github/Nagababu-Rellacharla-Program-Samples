     
            function review() {
                //document.getElementById("writeReview").style.visibility = 'visible';
                 document.getElementById("com").style.visibility = 'visible';
                document.getElementById("com1").style.visibility = 'visible';
                
            }

            window.onload = function () {
               // document.getElementById("writeReview").style.visibility = 'hidden';
                document.getElementById("write").onclick = review;
                document.getElementById("userId").value = "Nagababu";
                //document.getElementById("com").style.visibility = 'hidden';
                //document.getElementById("com1").style.visibility = 'hidden';
                $("#dropdown").on("click", function(e){
  e.preventDefault();
  
  if($(this).hasClass("open")) {
    $(this).removeClass("open");
    $(this).children("ul").slideUp("fast");
  } else {
    $(this).addClass("open");
    $(this).children("ul").slideDown("fast");
  }
});
            };
        