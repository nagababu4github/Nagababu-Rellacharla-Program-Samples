/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hcifinalproject;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author S522618
 */
@Entity
@Table(name = "USER_SONG_RATE")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "UserSongRate.findAll", query = "SELECT u FROM UserSongRate u"),
    @NamedQuery(name = "UserSongRate.findByUserId", query = "SELECT u FROM UserSongRate u WHERE u.userSongRatePK.userId = :userId"),
    @NamedQuery(name = "UserSongRate.findBySongId", query = "SELECT u FROM UserSongRate u WHERE u.userSongRatePK.songId = :songId"),
    @NamedQuery(name = "UserSongRate.findByRating", query = "SELECT u FROM UserSongRate u WHERE u.rating = :rating"),
    @NamedQuery(name = "UserSongRate.findByComments", query = "SELECT u FROM UserSongRate u WHERE u.comments = :comments")})
public class UserSongRate implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected UserSongRatePK userSongRatePK;
    @Basic(optional = false)
    @NotNull
    @Column(name = "RATING")
    private int rating;
    @Size(max = 100)
    @Column(name = "COMMENTS")
    private String comments;

    public UserSongRate() {
    }

    public UserSongRate(UserSongRatePK userSongRatePK) {
        this.userSongRatePK = userSongRatePK;
    }

    public UserSongRate(UserSongRatePK userSongRatePK, int rating) {
        this.userSongRatePK = userSongRatePK;
        this.rating = rating;
    }

    public UserSongRate(int userId, int songId) {
        this.userSongRatePK = new UserSongRatePK(userId, songId);
    }

    public UserSongRatePK getUserSongRatePK() {
        return userSongRatePK;
    }

    public void setUserSongRatePK(UserSongRatePK userSongRatePK) {
        this.userSongRatePK = userSongRatePK;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (userSongRatePK != null ? userSongRatePK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof UserSongRate)) {
            return false;
        }
        UserSongRate other = (UserSongRate) object;
        if ((this.userSongRatePK == null && other.userSongRatePK != null) || (this.userSongRatePK != null && !this.userSongRatePK.equals(other.userSongRatePK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hcifinalproject.UserSongRate[ userSongRatePK=" + userSongRatePK + " ]";
    }
    
}
