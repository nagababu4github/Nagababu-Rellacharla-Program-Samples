/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rellacharlalab10streams;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.function.Predicate;
import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
 *
 * @author Nagababu Rellacharla
 */
public class RellacharlaLab10Streams {

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException {

        ArrayList<Integer> intarr = new ArrayList<>();

        Scanner in = new Scanner(new File("data.txt"));
        while (in.hasNext()) {
            int number1 = in.nextInt();
            intarr.add(number1);
        }
        Stream<Integer> s0 = intarr.stream();
        IntStream mapto1 = s0.mapToInt(n -> 1);
        int numberofelements = mapto1.reduce(0, (m, n) -> m + n);
        System.out.println("Number of elements in the Stream: " + numberofelements);
        Stream<Integer> s1 = intarr.stream();
        int totalNumbers = (int) s1.count();
        System.out.println("Number of elements in the Stream using" + " 'count' " + "method: " + totalNumbers);
        Stream<Integer> s2 = intarr.stream();
        Stream<Integer> evenInt = s2.filter(n -> (n % 2 == 0));
        Stream<Integer> evenLess100 = evenInt.filter(n -> n < 100);
        int evensumless100 = evenLess100.reduce(0, (m, n) -> m + n);
        System.out.println("Sum of even integers that are less than 100: " + evensumless100);
        Stream<Integer> s3 = intarr.stream();
        IntStream doubleelements = s3.mapToInt(n -> n * 2);
        IntStream divisibleby10 = doubleelements.filter(n -> n % 10 == 0);
        System.out.println("Number of elements in the Stream that are divisible by 10 after multiplying by 2: " + divisibleby10.count());
        Stream<Integer> s4 = intarr.stream();
        System.out.println("Stream contains the element 150? " + s4.anyMatch(n -> n == 150));
        List<String> myList = Arrays.asList("apple", "banana", "pear", "orange", "grape");
        myList.stream()
                .filter(s -> s.startsWith("p"))
                .map(String::toUpperCase)
                .sorted()
                .forEach(System.out::println);
        // Expected output:PEAR && Actual Output:PEAR
        //"::" means that for each string of the stream applies the features that we mentioned after "::" that is,
        //converts all strings to uppercase in the stream 
        //the left part of the "::" is the calss and the right part of the "::" is the method in the class here
        Stream.of("a1", "b2", "g1")
                .map(s -> s.substring(1))
                .mapToInt(Integer::parseInt)
                .max()
                .ifPresent(System.out::println);

    }

}
