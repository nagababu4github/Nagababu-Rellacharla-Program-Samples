/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package takehome;

/**
 *
 * @author Nagababu Rellacharla
 */
public class H1applicants {

    private int stationNo;
    private double latitude;
    private double longitude;
    private int year;
    private int noH1Applications;

    public H1applicants(int stationNo, double latitude, double longitude, int year, int noH1Applications) {
        this.stationNo = stationNo;
        this.latitude = latitude;
        this.longitude = longitude;
        this.year = year;
        this.noH1Applications = noH1Applications;
    }

    public void setStationNo(int stationNo) {
        this.stationNo = stationNo;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public void setNoH1Applications(int noH1Applications) {
        this.noH1Applications = noH1Applications;
    }

    public int getStationNo() {
        return stationNo;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public int getYear() {
        return year;
    }

    public int getNoH1Applications() {
        return noH1Applications;
    }

}
