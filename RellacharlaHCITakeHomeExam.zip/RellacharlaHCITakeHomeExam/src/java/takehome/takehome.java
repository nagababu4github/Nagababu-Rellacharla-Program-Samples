/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package takehome;

import com.google.gson.Gson;
import com.sun.jmx.snmp.BerDecoder;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;

/**
 *
 * @author Nagababu Rellacharla
 */
@WebServlet(name = "takehome", urlPatterns = {"/takehome"})
public class takehome extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String[] yearRequired = request.getParameterValues("year");
        response.setContentType("application/json;charset=UTF-8");

        try (PrintWriter out = response.getWriter()) {
            Scanner sc = new Scanner(new File("C:\\takehome.txt"));
            ArrayList<H1applicants> movieList = new ArrayList<>();
            ArrayList<H1applicants> result = new ArrayList<>();
            while (sc.hasNext()) {
                String details = sc.nextLine();
                String[] detailsSplitted = details.split(",");
                int station = Integer.parseInt(detailsSplitted[0]);
                double lattitude = Double.parseDouble(detailsSplitted[1]);
                double longtitude = Double.parseDouble(detailsSplitted[2]);
                int year = Integer.parseInt(detailsSplitted[3]);
                int movies = Integer.parseInt(detailsSplitted[4]);
                H1applicants m1 = new H1applicants(station, lattitude, longtitude, year, movies);
                movieList.add(m1);

            }
            for (H1applicants m : movieList) {
                for (int i = 0; i < yearRequired.length; i++) {
                    if (m.getYear() == Integer.parseInt(yearRequired[i])) {
                        result.add(m);
                    }
                }
            }

            Gson gson = new Gson();
            String json = gson.toJson(result);
            request.setAttribute("jspoint", json); //"jspoint" is also used in JSP
            RequestDispatcher view = request.getRequestDispatcher("/takehome.jsp");
            view.forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
