/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function orderTotal() {
    var price = 0.00;
    PLAIN_CONE = 0.30;
    WAFFLE_CONE = 0.50;
    CUP = 0.20;
    EACH_SCOOP = 0.75;
    SPRINKLE = 0.25;
    CARAMEL_GOO = 0.35;
    CHOCOLATE_SAUCE = 0.40;
    CHOPPED_WALNUT = 0.45;
    var isAllDataEntered = true;
    var error = "";
    $('#ice').hide();
    //Checking whether cone or cup is selected and calcualting price

    if ($(":radio[name=cone]:checked").val() == "1") {
        price += PLAIN_CONE;
    }
    else if ($(":radio[name=cone]:checked").val() == "2") {
        price += WAFFLE_CONE;
    }
    else if ($(":radio[name=cone]:checked").val() == "3") {
        price += CUP;
    }
    else
    {
        isAllDataEntered = false;
        error = "Select cone or cup.<br>";
    }
    //Selecting Flavor
    if ($('#flavorType').val() == "chooseFlavour") {
        isAllDataEntered = false;
        error += "Select flavor. <br>";
        $('body').css('background', 'none');

    }


    //}

//Checking for number of scoops
    if ($(":radio[name=on]:checked").val() == "4") {
        price += EACH_SCOOP;
    }
    else if ($(":radio[name=on]:checked").val() == "5") {
        price += 2 * EACH_SCOOP;
    }
    else if ($(":radio[name=on]:checked").val() == "6") {
        price += 3 * EACH_SCOOP;
    }
    else
    {
        isAllDataEntered = false;
        error += "Select the number of scoops.<br>";
    }
//Calculating price for extras

    if ($(":checkbox[id=sprinkels]:checked").val() == "spr") {
        price += SPRINKLE;
    }
    if ($(":checkbox[name=caramel]:checked").val() == "caramel") {
        price += CARAMEL_GOO;
    }
    if ($(":checkbox[name=choco]:checked").val() == "Choc") {
        price += CHOCOLATE_SAUCE;
    }
    if ($(":checkbox[name=chopped]:checked").val() == "chopped") {
        price += CHOPPED_WALNUT;
    }

    if ($('#name').val() == "") {
        isAllDataEntered = false;
        error += "Enter your name.<br> ";
    }

    if (isAllDataEntered == false) {
        $('#orderDetails').html("");
        $('body').css('background', 'none');
        $('#ice').hide();
        $('#errorNam').html(error);

    }
    else
    {
        $('#errorNam').html("");
        $('#ice').css('size', '100%');
        $('#ice').slideDown(5000);
        $('#orderDetails').html("Your " + $('#flavorType').val() + " ice cream will be ready soon, " +
                $('#name').val() + ".<br> Your order total is $" + price.toFixed(2) + ".");
        if ($('#flavorType').val() == "vanilla") {
            $("body").css('background', 'cornsilk');
        } else if ($('#flavorType').val() == "Chocolate") {
            $("body").css('background', 'sienna');
        } else if ($('#flavorType').val() == "mango") {
            $("body").css('background', 'gold');
        } else if ($('#flavorType').val() == "cherry") {
            $("body").css('background', 'pink');
        } else if ($('#flavorType').val() == "peach") {
            $("body").css('background', 'orange');
        }
    }
}
$(document).ready(function () {
    $("#order").click(orderTotal);
    $('#ice').hide();
});