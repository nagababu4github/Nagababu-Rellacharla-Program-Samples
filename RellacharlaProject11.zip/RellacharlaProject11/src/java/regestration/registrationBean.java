/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package regestration;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.inject.Named;

/**
 *
 * @author Nagababu Rellacharla
 */
@ManagedBean
@Named(value = "registrationBean")
@RequestScoped
public class registrationBean {

    private String fname;
    private String passwd;
    private int gre;
    private double gpa;
    private String lastname;

    /**
     * Creates a new instance of registrationBean
     */
    public registrationBean() {
    }

    public String getFname() {
        return fname;
    }

    public String getLastname() {
        return lastname;
    }

    public String getPasswd() {
        return passwd;
    }

    public int getGre() {
        return gre;
    }

    public double getGpa() {
        return gpa;
    }

    public void setFname(String fname) {
        this.fname = fname.trim();
    }

    public void setLastname(String lastname) {
        this.lastname = lastname.trim();
    }

    public void setPasswd(String passwd) {
        this.passwd = passwd;
    }

    public void setGre(int gre) {
        this.gre = gre;
    }

    public void setGpa(double gpa) {
        this.gpa = gpa;
    }

    public String getUserName() {
         String s = fname.charAt(0) + "" + fname.charAt(fname.length() - 1) + lastname.charAt(0) + lastname.charAt(lastname.length() - 1);
         return s.toLowerCase();
    }
    public int getIndex(){
        
                double d = (double)(gre-130)/10 + gpa;
        double d2 = d*12.5;
        int index = (int) Math.round(d2);
     return index;   
    }

}
